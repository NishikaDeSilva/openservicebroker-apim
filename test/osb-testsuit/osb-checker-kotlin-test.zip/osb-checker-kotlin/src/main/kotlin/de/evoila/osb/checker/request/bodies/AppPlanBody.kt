package de.evoila.osb.checker.request.bodies



data class Person(val name: String, val version: String) {
}