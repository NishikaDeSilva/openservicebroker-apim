package de.evoila.osb.checker.request.bodies

import java.io.Serializable


interface RequestBody : Serializable