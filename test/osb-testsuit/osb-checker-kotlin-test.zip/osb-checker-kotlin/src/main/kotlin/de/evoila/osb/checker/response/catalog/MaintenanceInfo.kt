package de.evoila.osb.checker.response.catalog

data class MaintenanceInfo(
    val version: String,
    val description: String
)