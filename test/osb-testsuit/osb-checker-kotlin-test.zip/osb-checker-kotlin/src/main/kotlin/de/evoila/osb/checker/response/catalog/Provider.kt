package de.evoila.osb.checker.response.catalog

data class Provider(
    val name: String
)